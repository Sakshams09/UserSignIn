package com.example.signin.Service;
import com.example.signin.Entity.SigninEntity;
import com.example.signin.Repository.SigninRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Signinservice {
    @Autowired
    public SigninRepo sr;

    public SigninEntity saveUser(SigninEntity se){
      return sr.save(se);

    }
}
