package com.example.signin.Controller;

import com.example.signin.Entity.SigninEntity;
import com.example.signin.Service.Signinservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
public class SigninController {

    @Autowired
    public Signinservice sc;

    @RequestMapping("/add")
    public SigninEntity add( @RequestBody SigninEntity se){
    return sc.saveUser(se);
    }


}
