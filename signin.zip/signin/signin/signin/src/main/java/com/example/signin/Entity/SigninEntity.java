package com.example.signin.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Table(name="User")
@NoArgsConstructor
@AllArgsConstructor
@Entity

public class SigninEntity {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;
private String name;
}
